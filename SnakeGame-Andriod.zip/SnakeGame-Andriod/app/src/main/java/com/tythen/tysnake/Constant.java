package com.tythen.tysnake;

public class Constant {
    public static final int defaultTablePoints = 3;//初始化一共多少个点
    public static final int pointSize = 28;
    public static final int snakeColor = R.color.green;
    public static final int snakeMovingSpeed = 800;
    public static final int foodColor = R.color.red;
}
